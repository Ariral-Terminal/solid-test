export ZSH="$HOME/.oh-my-zsh"
export PATH="$HOME/.local/bin:$PATH"
export ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE='fg=244'

ZSH_THEME="agnoster"
plugins=(git history fzf zsh-syntax-highlighting zsh-completions zsh-autosuggestions)

source $ZSH/oh-my-zsh.sh

clear

alias zshconfig="nvim ~/.zshrc"
alias ohmyzsh="nvim ~/.oh-my-zsh"
