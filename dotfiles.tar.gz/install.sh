#!/bin/bash
set -e

# --- Pacman packages ---
PACMAN_PKGS=(
    wget curl psmisc gcc rust cmake clang ninja hyprland xdg-desktop-portal-hyprland
    waybar mako hyprpaper hyprlock hypridle hyprpicker fuzzel brightnessctl playerctl
    grim slurp wl-clipboard cliphist thunar tumbler pavucontrol network-manager-applet
    xarchiver seahorse nwg-look vlc kitty pipewire pipewire-alsa pipewire-pulse wireplumber
    sddm papirus-icon-theme qt5ct kvantum qt6ct gtk3 gtk4 ttf-jetbrains-mono-nerd
    ttf-montserrat git fzf tmux fastfetch jq btop bat zsh
    neovim micro cava cmatrix libnotify polkit gnome-keyring polkit-gnome
)

# --- AUR packages (yay/paru) ---
AUR_PKGS=(zen-browser-bin bibata-cursor-theme)

echo "==> Installing pacman packages..."
sudo pacman -S --needed "${PACMAN_PKGS[@]}"

if command -v yay &>/dev/null; then
    AUR_HELPER=yay
elif command -v paru &>/dev/null; then
    AUR_HELPER=paru
else
    echo "==> No AUR helper found. Installing yay..."
    sudo pacman -S --needed git base-devel
    git clone https://aur.archlinux.org/yay.git /tmp/yay
    (cd /tmp/yay && makepkg -si --noconfirm)
    AUR_HELPER=yay
fi

echo "==> Installing AUR packages with $AUR_HELPER..."
$AUR_HELPER -S --needed "${AUR_PKGS[@]}"

echo "==> Installing Oh My Zsh..."
if [ ! -d "$HOME/.oh-my-zsh" ]; then
    sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended
fi

echo "==> Installing Oh My Zsh plugins..."
ZSH_CUSTOM=${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}
mkdir -p "$ZSH_CUSTOM/plugins"
git clone https://github.com/zsh-users/zsh-autosuggestions "$ZSH_CUSTOM/plugins/zsh-autosuggestions" --depth 1 2>/dev/null || true
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting" --depth 1 2>/dev/null || true
git clone https://github.com/zsh-users/zsh-completions.git "$ZSH_CUSTOM/plugins/zsh-completions" --depth 1 2>/dev/null || true

echo "==> Enabling services..."
sudo systemctl enable sddm
sudo systemctl enable fstrim.timer
systemctl --user enable pipewire pipewire-pulse wireplumber

echo "==> Deploying dotfiles..."
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp -r "$SCRIPT_DIR/.config/"* ~/.config/
cp "$SCRIPT_DIR/.zshrc" ~/.zshrc

echo "==> Setting zsh as default shell..."
chsh -s /usr/bin/zsh

echo "Done! Reboot to start Hyprland via SDDM."
